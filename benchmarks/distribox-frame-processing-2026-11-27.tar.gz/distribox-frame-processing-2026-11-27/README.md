# Reproduce the Distribox framebuffer comparison

The before build is Gliss beta.3, commit `96bb42db`. The candidate code is `1eacdcad`. The follow-up benchmark commit only changes when its synthetic drag releases the pointer. Both server builds use portable release flags. The native measurements require Linux. The measured AVX2 implementation is selected at runtime on supported x86-64 hosts. Install the Gliss native build prerequisites and fetch the locked Cargo dependencies.

From a shell in the extracted archive, set `before` and `after` to absolute paths to the respective Gliss checkouts. Use two distinct output binaries for each comparison. The build helpers create temporary Cargo packages outside the checkouts. The driver uses P-cores 2, 4 and 6 on the measurement host. Edit those affinities for a different CPU topology.

```bash
set -eu
unset RUSTFLAGS
work=$(mktemp -d)
for stage in rfb prepare; do
  for label in before after; do
    bash "replay/$stage/build.sh" "${!label}" "$work/$stage-build"
    cp "$work/$stage-build/target/release/$stage-replay" "$work/$stage-$label"
  done
  python3 replay/paired.py "$stage" "$work/$stage-before" "$work/$stage-after" "$work/$stage.json"
done
```

The RFB replay takes four updates from each of scroll, drag and page turns. It generates deterministic BGRX pixels and checks every output byte and dirty tile for each sampled update. The staging replay takes up to 32 evenly spaced tile masks per activity. It cycles four RGBA buffers after an initial full encode. Each timing sample is the median of five batches of at least 60 ms. Both final replays measure Linux thread CPU time. Each comparison has six pairs and reverses the build order each pair.

For the full stream, install Playwright and Chromium in the after checkout. Install the Python dependencies in `~/projects/Distribox/backend/venv` at Distribox revision `56dd937c`. The relay adapter imports the actual forwarding functions from that checkout. See Gliss's development guide for the diskless QEMU/KVM fixture. Choose a guest kernel and matching modules.

```bash
for label in before after; do
  (cd "${!label}" && cargo build --release --locked -p gliss-server)
  cp "${!label}/target/release/gliss-server" "$work/server-$label"
done
export GLISS_CHECKOUT="$after" TMPDIR=/dev/shm
taskset -c 0,2,4,6,8,10 bash replay/relays/run.sh \
  --binary "$work/server-before" --label before --binary "$work/server-after" --label after \
  --h264-bitrate 8000000 --rounds 4 --typing-keys 8 \
  --scenarios typing,scroll,drag,video,pages --output "$work/relays8.json"
```

For the shipped 2 Mbit/s default, repeat with `--h264-bitrate 2000000 --rounds 2 --scenarios scroll,drag,video`. The live fixture also records a five-second idle window after each viewer session. Each output retains the per-round CPU, browser paint and input-marker samples, process versions, binary hashes, flags, host load, failures and warnings.

The primary eight-session run in `relays8.json` used the original beta.3 benchmark schedule. It sent button-up immediately after its final move. The benchmark now holds the button through the observation window. Data for the corrected four-round comparison is in `drag8.json`. Use the current benchmark for the commands above, with `--scenarios drag` to reproduce that comparison. To reproduce the original schedule, point `GLISS_CHECKOUT` at a checkout containing the beta.3 benchmark or use the archived `replay/relays/original-bench.mjs` in its place. The server binaries are independently specified.

Run `python3 plot.py --data-dir data --out-dir .` with Matplotlib installed to regenerate the static and interactive charts.
