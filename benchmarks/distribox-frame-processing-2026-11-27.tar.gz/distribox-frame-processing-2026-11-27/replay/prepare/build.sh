#!/usr/bin/env bash
set -euo pipefail
root=$(cd "${1:?Gliss checkout}" && pwd)
src=$(cd "$(dirname "$0")" && pwd)
out=${2:?external build directory}
mkdir -p "$out"
out=$(cd "$out" && pwd)
ln -sfn "$src" "$out/driver"
cp "$root/Cargo.lock" "$out/Cargo.lock"
python3 - "$root" "$out" <<'PY'
import json, pathlib, sys
root,out=map(pathlib.Path,sys.argv[1:])
(out/'Cargo.toml').write_text("""
[workspace]
resolver = "2"
[package]
name = "prepare-replay"
version = "0.0.0"
edition = "2024"
[[bin]]
name = "prepare-replay"
path = "driver/main.rs"
[dependencies]
libc = "0.2"
gliss-core = {path = %s}
gliss-video = {path = %s}
[profile.release]
lto = "thin"
codegen-units = 1
""" % tuple(json.dumps(str(root/'crates'/name)) for name in ('gliss-core','gliss-video')))
PY
cd "$root"
env -u RUSTFLAGS CARGO_TARGET_DIR="$out/target" cargo build --release --offline --manifest-path "$out/Cargo.toml" -j 4
