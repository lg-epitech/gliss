use gliss_core::{Damage, Frame};
use gliss_video::VideoEncoder;
use std::{
    hint::black_box,
    time::Duration,
};

const WIDTH: u16 = 1920;
const HEIGHT: u16 = 1080;
const TRACES: &str = include_str!("tiles.txt");

fn thread_cpu() -> Duration {
    let mut t = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    // Linux: count time scheduled on this thread, including its kernel time.
    assert_eq!(unsafe { libc::clock_gettime(libc::CLOCK_THREAD_CPUTIME_ID, &mut t) }, 0);
    Duration::new(t.tv_sec as u64, t.tv_nsec as u32)
}

fn main() {
    let mut frames = Vec::new();
    for seed in 1..=4 {
        let mut frame = Frame::new(WIDTH, HEIGHT).unwrap();
        let mut rng = seed as u32;
        for pixel in frame.pixels.chunks_exact_mut(4) {
            rng = rng.wrapping_mul(1664525).wrapping_add(1013904223);
            pixel[..3].copy_from_slice(&rng.to_le_bytes()[1..]);
        }
        frames.push(frame);
    }
    let mut encoder = VideoEncoder::with_bitrate(WIDTH, HEIGHT, 30, 8_000_000).unwrap();
    encoder.encode(&frames[0], 0, 0).unwrap();
    let mut log_sum = 0.0;
    let mut count = 0;
    for scenario in ["typing", "scroll", "drag", "video", "pages", "full"] {
        let mut masks = Vec::new();
        for line in TRACES.lines() {
            let mut fields = line.split_whitespace();
            if fields.next() != Some(scenario) {
                continue;
            }
            let mut mask = Damage::empty(WIDTH, HEIGHT);
            for (row, field) in fields.enumerate() {
                let bits = u32::from_str_radix(field, 16).unwrap();
                for col in 0..30 {
                    if bits & (1 << col) != 0 {
                        mask.mark_rect(col * 64, row as u16 * 64, 64, 64);
                    }
                }
            }
            masks.push(mask);
        }
        if scenario == "full" {
            masks.push(Damage::full(WIDTH, HEIGHT));
        }
        assert!(!masks.is_empty());
        let mut batches = Vec::new();
        let mut n = 0usize;
        for _ in 0..5 {
            let start = thread_cpu();
            let mut calls = 0;
            loop {
                for mask in &masks {
                    encoder
                        .prepare_damaged(black_box(&frames[n % frames.len()]), black_box(mask))
                        .unwrap();
                    black_box(&mut encoder);
                    n += 1;
                    calls += 1;
                }
                if (thread_cpu() - start) >= Duration::from_millis(60) {
                    break;
                }
            }
            batches.push((thread_cpu() - start).as_secs_f64() * 1e6 / f64::from(calls));
        }
        batches.sort_by(f64::total_cmp);
        println!("SCENE {scenario} {:.6}", batches[2]);
        if scenario != "full" {
            log_sum += batches[2].ln();
            count += 1;
        }
    }
    println!(
        "METRIC prepare_us={:.6}",
        (log_sum / f64::from(count)).exp()
    );
}
