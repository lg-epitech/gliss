import argparse,json,hashlib,re,subprocess,pathlib
p=argparse.ArgumentParser()
p.add_argument('stage',choices=['prepare','rfb'])
p.add_argument('before',type=pathlib.Path)
p.add_argument('after',type=pathlib.Path)
p.add_argument('out',type=pathlib.Path)
p.add_argument('--pairs',default=6,type=int)
a=p.parse_args()
paths={'before':a.before.resolve(),'after':a.after.resolve()}
res={'stage':a.stage,'clock':'CLOCK_THREAD_CPUTIME_ID','binarySha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in paths.items()},'pairs':[]}
for i in range(a.pairs):
    pair={}
    for label in (['before','after'] if i%2==0 else ['after','before']):
        if a.stage=='prepare':
            cmd=['taskset','-c','6',str(paths[label])]
        else:
            cmd=['env','RFB_REPLAY_CPU=2','RFB_REPLAY_PEER_CPU=4',str(paths[label]),'48']
        output=subprocess.check_output(cmd,text=True)
        if a.stage=='prepare':
            values={s:float(us) for s,us in re.findall(r'SCENE (\w+) ([0-9.]+)',output)}
        else:
            values={s:float(ms)*1000/int(n) for s,n,ms in re.findall(r'^([a-z]+) .*timed_frames=(\d+) reader_cpu_ms=([0-9.]+)',output,re.M)}
        assert len(values)==(6 if a.stage=='prepare' else 3)
        values['overall']=float(re.search(r'METRIC \w+=([0-9.]+)',output)[1])
        pair[label]={'usPerUpdate':values,'stdout':output}
    res['pairs'].append(pair)
    a.out.write_text(json.dumps(res,indent=2)+'\n')
    print(i+1,{k:round(v['usPerUpdate']['overall'],2) for k,v in pair.items()},flush=True)
