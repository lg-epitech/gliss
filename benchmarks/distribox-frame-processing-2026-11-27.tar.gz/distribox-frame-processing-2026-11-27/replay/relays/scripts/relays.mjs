import {spawn} from 'node:child_process';
import {homedir} from 'node:os';
import {fileURLToPath} from 'node:url';

const python = homedir() + '/projects/Distribox/backend/venv/bin/python';
const workerScript = fileURLToPath(new URL('../relay.py', import.meta.url));
async function worker(role, targetPort) {
  const child = spawn(python, [workerScript, role, String(targetPort)], {
    env: {...process.env, PYTHONDONTWRITEBYTECODE: '1'},
    stdio: ['ignore','pipe','inherit']
  });
  const exited = new Promise(resolve => child.once('exit', resolve));
  const stop = async () => {
    if (child.exitCode !== null || child.signalCode) return;
    child.kill('SIGTERM');
    const kill = setTimeout(() => child.kill('SIGKILL'), 2500);
    try { await exited; } finally { clearTimeout(kill); }
  };
  try {
    const {port} = await Promise.race([
      (async () => {
        let out = '';
        for await (const data of child.stdout) {
          out += data.toString();
          if (out.includes('\n')) return JSON.parse(out.split('\n')[0]);
        }
        throw new Error(role + ' relay exited during startup');
      })(),
      new Promise((_, reject) => {
        child.once('error', reject);
        const timeout = setTimeout(() => reject(new Error('Timed out starting ' + role)), 12000);
        timeout.unref();
      }),
    ]);
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid relay port');
    return {port, pid: child.pid, stop};
  } catch (error) { await stop(); throw error; }
}
export async function startRelays(server) {
  const slave = await worker('slave', server.port);
  try {
    const master = await worker('master', slave.port);
    return {port: master.port, url: 'http://127.0.0.1:' + master.port, token: server.token, master, slave,
      stop: async() => { await master.stop(); await slave.stop(); }};
  } catch (error) { await slave.stop(); throw error; }
}
