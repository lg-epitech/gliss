#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
repo=${GLISS_CHECKOUT:-$(pwd)}
export PYTHONDONTWRITEBYTECODE=1
python3 "$base/prepare.py" "$repo"
export TMPDIR=${TMPDIR:-/dev/shm}
exec node "$base/scripts/bench.mjs" "$@"
