from pathlib import Path
import os
import sys
import hashlib
import json
import subprocess

out = Path(__file__).resolve().parent
gliss = Path(sys.argv[1]).resolve()
for name in ["tests", "test-support", "node_modules"]:
    path = out / name
    source = gliss / name
    if path.is_symlink():
        path.unlink()
    path.symlink_to(source)
source = (gliss / "scripts/bench-distribox-path.mjs").read_text()
def replace(old, new):
    global source
    if source.count(old) != 1:
        raise ValueError("Upstream benchmark adapter mismatch: " + old)
    source = source.replace(old, new)
replace("const options =", "import {startRelays} from './relays.mjs';\nconst options =")
replace("bitrate, origin: link?.origin", "bitrate")
replace("const viewer = await openViewer(browser, link ? await link.attach(server) : server)", """const relays = await startRelays(server);
    started(relays.stop);
    server.relays = relays;
    const viewer = await openViewer(browser, link ? await link.attach(relays) : relays)""")
replace("await link?.detach();", "await link?.detach();\n    await finished(relays.stop);")
replace("const cpu = {server: cpuBetween", """const cpu = {relaySlave: cpuBetween(before, after, [server.relays.slave.pid]), relayMaster: cpuBetween(before, after, [server.relays.master.pid]),
    server: cpuBetween""")
replace("const cpuTotal = run.cpu.server + run.cpu.qemu + run.cpu.chromium;", "const cpuTotal = run.cpu.server + run.cpu.qemu + run.cpu.chromium + run.cpu.relayMaster + run.cpu.relaySlave;")
replace("serverCpuMs: run.cpu.server,", """relayMasterCpuMs: run.cpu.relayMaster, relaySlaveCpuMs: run.cpu.relaySlave,
    relayMasterCpuMsPerFrame: painted.length ? run.cpu.relayMaster / painted.length : undefined,
    relaySlaveCpuMsPerFrame: painted.length ? run.cpu.relaySlave / painted.length : undefined,
    serverCpuMs: run.cpu.server,""")
distribox = Path.home() / "projects/Distribox"
py = str(distribox / "backend/venv/bin/python")
versions = subprocess.check_output([py, "-c", "import importlib.metadata as m, json; print(json.dumps({pkg:m.version(pkg) for pkg in ['fastapi','uvicorn','uvloop','websockets','httpx']}))"], text=True)
source_info = {"path": "QEMU VNC -> Gliss -> Distribox local_stream (slave) -> Distribox slave_stream (master) -> Chromium", "distriboxCommit":subprocess.check_output(["git","-C",str(distribox),"rev-parse","HEAD"],text=True).strip(), "relayModuleSha256":hashlib.sha256((distribox/"backend/app/services/desktop_stream.py").read_bytes()).hexdigest(), "packages":json.loads(versions), "relayHops":2, "scope":"Production websocket forwarding and connector functions with synthetic API routes and substituted process startup. HTTP uses the stock Gliss page and login. Each hop runs as a separate local Uvicorn process."}
replace("const results = {", "const results = {\n  relay: " + json.dumps(source_info) + ",")
(out / "scripts/bench.mjs").write_text(source)
