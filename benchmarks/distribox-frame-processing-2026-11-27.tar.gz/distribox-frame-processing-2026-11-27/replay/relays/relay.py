"""Loopback-only adapter for two unchanged Distribox relay workers."""
import asyncio
import ctypes
import hmac
import json
import os
import signal
import socket
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from types import SimpleNamespace

import httpx
import uvicorn
import uvloop
from fastapi import FastAPI, Request, Response, WebSocket

sys.path.insert(0, str(Path.home() / "projects/Distribox/backend"))
from app.services import desktop_stream

master = sys.argv[1] == "master"
port = int(sys.argv[2])
origin = f"http://127.0.0.1:{port}"
socket_url = f"ws://127.0.0.1:{port}/ws"
fixture_token = "local-benchmark-slave"
session_cookie = ""
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)


@asynccontextmanager
async def existing_gliss(_host, _port):
    if not session_cookie:
        raise RuntimeError("The Gliss login has not completed")
    yield socket_url, {"Origin": origin, "Cookie": session_cookie}


desktop_stream.gliss_session = existing_gliss


@app.api_route("/{path:path}", methods=["GET", "POST", "DELETE"])
async def viewer(path: str, request: Request):
    global session_cookie
    # Preserve the stock Gliss viewer, assets, login and session cookie.
    # No cross-origin browser exception is necessary.
    headers = {"Origin": origin}
    for key in ["content-type", "cookie"]:
        if key in request.headers:
            headers[key] = request.headers[key]
    async with httpx.AsyncClient(trust_env=False) as client:
        upstream = await client.request(request.method, origin + "/" + path,
                                        content=await request.body(), headers=headers)
    if request.method == "POST" and path == "api/session" and upstream.is_success:
        session_cookie = upstream.headers["set-cookie"].partition(";")[0]
    copy = {key: value for key, value in upstream.headers.items()
            if key in ("content-type", "set-cookie", "content-security-policy", "cache-control", "referrer-policy", "x-content-type-options")}
    return Response(upstream.content, status_code=upstream.status_code, headers=copy)


@app.websocket("/ws")
@app.websocket("/vms/{vm_id}/desktop/tunnel")
async def desktop(ws: WebSocket, vm_id: str = "benchmark"):
    if master:
        if not session_cookie or not hmac.compare_digest(ws.headers.get("cookie", ""), session_cookie):
            return await ws.close(code=1008)
        node = SimpleNamespace(hostname="127.0.0.1", port=port, api_key=fixture_token)
        upstream = desktop_stream.slave_stream(node, vm_id)
    else:
        if not hmac.compare_digest(ws.headers.get("x-slave-token", ""), fixture_token):
            return await ws.close(code=1008)
        upstream = desktop_stream.local_stream("benchmark", 1)
    await desktop_stream.relay_stream(ws, upstream)


async def serve():
    # Workers belong to the benchmark and exit if their launcher is killed.
    parent = os.getppid()
    ctypes.CDLL(None).prctl(1, signal.SIGTERM, 0, 0, 0)
    if os.getppid() != parent or parent == 1:
        return
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        worker = uvicorn.Server(uvicorn.Config(app, lifespan="off", access_log=False,
                                                log_level="warning", ws_per_message_deflate=False))
        task = asyncio.create_task(worker.serve(sockets=[listener]))
        while not worker.started:
            if task.done():
                await task
                raise RuntimeError("relay failed during startup")
            await asyncio.sleep(.01)
        print(json.dumps({"port": listener.getsockname()[1]}), flush=True)
        await task


if __name__ == "__main__":
    uvloop.run(serve())
