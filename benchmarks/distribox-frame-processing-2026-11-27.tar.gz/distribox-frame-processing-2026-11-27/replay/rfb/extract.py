"""Retain four actual QEMU raw jobs at evenly spaced positions in each timed scene."""
import datetime
import json
import re
import struct
import sys
from pathlib import Path

trace_path, report_path, destination = map(Path, sys.argv[1:])
report = json.loads(report_path.read_text())
scenes = ("scroll", "drag", "pages")
assert report["size"] == "1920x1080"
windows = {name: report["runs"][0]["scenarios"][name]["host"] for name in scenes}
jobs = {name: [] for name in scenes}
pending = {}
rectangle = re.compile(r"job=(\S+) offset=(\d+),(\d+) size=(\d+)x(\d+)\s*$")
complete = re.compile(r"job=(\S+) nrects=(\d+)\s*$")
with trace_path.open() as trace:
    for line in trace:
        if "vnc_job_add_rect " in line:
            job, *values = rectangle.search(line).groups()
            rect = tuple(map(int, values))
            x, y, w, h = rect
            assert w and h and x + w <= 1920 and y + h <= 1080, rect
            pending.setdefault(job, []).append(rect)
        elif "vnc_job_nrects " in line:
            job, count = complete.search(line).groups()
            rects = pending.pop(job, [])
            assert len(rects) == int(count), (job, count, len(rects))
            time_ms = datetime.datetime.fromisoformat(line.split(maxsplit=1)[0]).timestamp() * 1000
            for scene, (start, end) in windows.items():
                if start <= time_ms < end and rects:
                    jobs[scene].append(rects)
        elif "vnc_job_" in line:
            raise ValueError(line)
assert not pending
with destination.open("wb") as output:
    output.write(b"RFBJ1")
    for scene in scenes:
        frames = jobs[scene]
        assert len(frames) >= 4
        indexes = [((2*i + 1)*len(frames))//8 for i in range(4)]
        for i in indexes:
            rects = frames[i]
            output.write(struct.pack(">H", len(rects)))
            for rect in rects:
                output.write(struct.pack(">4H", *rect))
        print(scene, "source jobs", len(frames), "indices", indexes, "rects", [len(frames[i]) for i in indexes],
              "wire pixels", [sum(w*h for _,_,w,h in frames[i]) for i in indexes])
