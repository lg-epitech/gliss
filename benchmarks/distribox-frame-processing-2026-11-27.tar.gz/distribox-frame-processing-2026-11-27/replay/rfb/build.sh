#!/usr/bin/env bash
set -euo pipefail
harness="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "${1:?Gliss checkout required}" && pwd)"
out="${2:?External build directory required}"
mkdir -p "$out"
out="$(cd "$out" && pwd)"
ln -sfn "$harness" "$out/driver"
cp "$repo/Cargo.lock" "$out/Cargo.lock"
cat > "$out/Cargo.toml" <<'TOML'
[workspace]
resolver = "2"

[package]
name = "rfb-replay"
version = "0.0.0"
edition = "2024"

[[bin]]
name = "rfb-replay"
path = "driver/main.rs"

[dependencies]
gliss-rfb = { path = "__GLISS_RFB__" }
libc = "0.2"
tokio = { version = "1", features = ["full"] }

[profile.release]
lto = "thin"
codegen-units = 1
TOML
# Start from the Gliss lockfile so its transitive versions are reused. Only the
# temporary wrapper package is new. Keep all generated Cargo files outside Gliss.
python3 - "$out/Cargo.toml" "$repo/crates/gliss-rfb" <<'PYTHON'
import json, pathlib, sys
manifest = pathlib.Path(sys.argv[1])
manifest.write_text(manifest.read_text().replace('"__GLISS_RFB__"', json.dumps(sys.argv[2])))
PYTHON
cd "$repo"
CARGO_TARGET_DIR="$out/target" cargo build --release --offline --manifest-path "$out/Cargo.toml" -j 2
