use gliss_rfb::{PooledEvent, connect};
use std::{
    convert::TryInto,
    env,
    io::{self, Read, Write},
    net::{TcpListener, TcpStream},
    sync::Arc,
    thread,
    time::Duration,
};

const W: u16 = 1920;
const H: u16 = 1080;
const JOBS: usize = 4;
const SCENES: [&str; 3] = ["scroll", "drag", "pages"];
const BGRX: [u8; 16] = [32, 24, 0, 1, 0, 255, 0, 255, 0, 255, 16, 8, 0, 0, 0, 0];
type Rect = [u16; 4];
type Job = Vec<Rect>;

fn geometry() -> [Vec<Job>; 3] {
    let mut remaining = include_bytes!("rects.bin").as_slice();
    assert_eq!(&remaining[..5], b"RFBJ1");
    remaining = &remaining[5..];
    let mut next = || {
        let (word, tail) = remaining.split_at(2);
        remaining = tail;
        u16::from_be_bytes(word.try_into().unwrap())
    };
    let result = std::array::from_fn(|_| {
        (0..JOBS)
            .map(|_| {
                let count = next();
                assert!(count > 0);
                (0..count)
                    .map(|_| {
                        let rect = std::array::from_fn(|_| next());
                        let [x, y, w, h] = rect;
                        assert!(w > 0 && h > 0 && x + w <= W && y + h <= H);
                        rect
                    })
                    .collect()
            })
            .collect()
    });
    assert!(remaining.is_empty());
    result
}

fn read_fixed<const N: usize>(s: &mut TcpStream) -> io::Result<[u8; N]> {
    let mut bytes = [0; N];
    s.read_exact(&mut bytes)?;
    Ok(bytes)
}

fn negotiate(s: &mut TcpStream) -> io::Result<()> {
    s.set_nodelay(true)?;
    s.set_read_timeout(Some(Duration::from_secs(10)))?;
    s.set_write_timeout(Some(Duration::from_secs(10)))?;
    s.write_all(b"RFB 003.008\n")?;
    assert_eq!(&read_fixed::<12>(s)?, b"RFB 003.008\n");
    s.write_all(&[1, 1])?;
    assert_eq!(read_fixed::<1>(s)?, [1]);
    s.write_all(&[0; 4])?;
    assert_eq!(read_fixed::<1>(s)?, [1]);
    let mut init = Vec::from(W.to_be_bytes());
    init.extend(H.to_be_bytes());
    init.extend(BGRX);
    init.extend(4u32.to_be_bytes());
    init.extend(b"QEMU");
    s.write_all(&init)?;
    let format = read_fixed::<20>(s)?;
    assert_eq!(&format[..4], &[0; 4]);
    assert_eq!(&format[4..], &BGRX);
    let encodings = read_fixed::<4>(s)?;
    assert_eq!(encodings[..2], [2, 0]);
    let n = u16::from_be_bytes(encodings[2..].try_into().unwrap());
    let mut has_raw = false;
    for _ in 0..n {
        has_raw |= i32::from_be_bytes(read_fixed(s)?) == 0;
    }
    assert!(has_raw);
    Ok(())
}

fn source_color(i: usize) -> [u8; 4] {
    // Fixed, coordinate-dependent BGRX. All channels differ, including X.
    let v = ((i as u32).wrapping_mul(0x1e53_ba8d) ^ 0x6719_38b1).to_le_bytes();
    [v[0], v[1], v[2], v[3]]
}

fn offset(x: u16, y: u16, phase: usize) -> usize {
    (usize::from(x) + usize::from(y) * 53 + phase * 191) % 4096
}

fn packet(rects: &[Rect], phase: usize, colors: &[u8], buf: &mut Vec<u8>) {
    buf.clear();
    buf.extend([0, 0]);
    buf.extend((rects.len() as u16).to_be_bytes());
    for &[x, y, w, h] in rects {
        for v in [x, y, w, h] {
            buf.extend(v.to_be_bytes());
        }
        buf.extend(0i32.to_be_bytes());
        for row in y..(y + h) {
            let begin = 4 * offset(x, row, phase);
            buf.extend_from_slice(&colors[begin..begin + 4 * usize::from(w)]);
        }
    }
}

fn serve(listener: TcpListener, jobs: Arc<Vec<Job>>, cycles: usize) -> io::Result<()> {
    pin_if_set("RFB_REPLAY_PEER_CPU");
    let (mut stream, _) = listener.accept()?;
    negotiate(&mut stream)?;
    // One packed update at a time, plus a 32 KiB repeating pixel source.
    let colors: Vec<u8> = (0..8192).flat_map(|i| source_color(i % 4096)).collect();
    let mut buf = Vec::with_capacity(4 * usize::from(W) * usize::from(H) + 4096);
    for index in 0..=cycles * jobs.len() {
        let phase = index
            .checked_sub(1)
            .map(|n| n % jobs.len() + 1)
            .unwrap_or(0);
        let rects = if phase == 0 {
            &[[0, 0, W, H]][..]
        } else {
            &jobs[phase - 1]
        };
        // Prepare before waiting for the consumer's next request, as if pixels were ready in QEMU.
        packet(rects, phase, &colors, &mut buf);
        let request = read_fixed::<10>(&mut stream)?;
        assert_eq!(&request[..6], &[3, u8::from(index != 0), 0, 0, 0, 0]);
        assert_eq!(&request[6..], &[W.to_be_bytes(), H.to_be_bytes()].concat());
        stream.write_all(&buf)?;
    }
    Ok(())
}

fn apply_reference(pixels: &mut [u8], rects: &[Rect], phase: usize) {
    for &[x, y, w, h] in rects {
        for row in y..y + h {
            let start = (usize::from(row) * usize::from(W) + usize::from(x)) * 4;
            for (column, out) in pixels[start..start + usize::from(w) * 4]
                .chunks_exact_mut(4)
                .enumerate()
            {
                let [b, g, r, _] = source_color(offset(x + column as u16, row, phase));
                out.copy_from_slice(&[r, g, b, 255]);
            }
        }
    }
}

fn hash(pixels: &[u8]) -> u64 {
    pixels.iter().fold(0xcbf29ce484222325, |h, &b| {
        (h ^ u64::from(b)).wrapping_mul(0x100000001b3)
    })
}

fn verify_pixels(actual: &[u8], expected: &[u8]) {
    assert_eq!(actual.len(), expected.len());
    if actual != expected {
        let index = actual
            .iter()
            .zip(expected)
            .position(|(a, b)| a != b)
            .unwrap();
        panic!(
            "wrong RGBA byte at {index}: got {}, expected {}",
            actual[index], expected[index]
        );
    }
}

fn tiles(rects: &[Rect]) -> Vec<bool> {
    let columns = usize::from(W.div_ceil(64));
    let mut bits = vec![false; columns * usize::from(H.div_ceil(64))];
    for &[x, y, w, h] in rects {
        for row in y / 64..=(y + h - 1) / 64 {
            for col in x / 64..=(x + w - 1) / 64 {
                bits[usize::from(row) * columns + usize::from(col)] = true;
            }
        }
    }
    bits
}

fn pin_if_set(variable: &str) {
    if let Ok(value) = env::var(variable) {
        let cpu: usize = value.parse().expect("invalid CPU index");
        assert!(cpu < libc::CPU_SETSIZE as usize);
        // Linux uses PID 0 here for the calling thread only.
        unsafe {
            let mut cpus: libc::cpu_set_t = std::mem::zeroed();
            libc::CPU_ZERO(&mut cpus);
            libc::CPU_SET(cpu, &mut cpus);
            assert_eq!(
                libc::sched_setaffinity(0, std::mem::size_of_val(&cpus), &cpus),
                0,
                "{variable}: {}",
                io::Error::last_os_error()
            );
        }
    }
}

fn thread_cpu() -> Duration {
    let mut ts = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // CLOCK_THREAD_CPUTIME_ID excludes the synchronous peer, kernel wait and CPU on other threads.
    assert_eq!(
        unsafe { libc::clock_gettime(libc::CLOCK_THREAD_CPUTIME_ID, &mut ts) },
        0
    );
    Duration::new(ts.tv_sec as u64, ts.tv_nsec as u32)
}

async fn replay(scene: &str, jobs: Vec<Job>, cycles: usize) -> (Duration, usize) {
    let jobs = Arc::new(jobs);
    let listener = TcpListener::bind(("127.0.0.1", 0)).unwrap();
    let addr = listener.local_addr().unwrap().to_string();
    let peer_jobs = jobs.clone();
    let peer = thread::spawn(move || serve(listener, peer_jobs, 1 + cycles));
    let (mut reader, mut writer, info) = connect(&addr, None).await.unwrap();
    assert_eq!((info.width, info.height), (W, H));
    let mut oracle = vec![0; 4 * usize::from(W) * usize::from(H)];
    // Seed the entire display, then check every byte and the exact dirty tile set of each sample.
    for index in 0..=JOBS {
        let rects = if index == 0 {
            &[[0, 0, W, H]][..]
        } else {
            &jobs[index - 1]
        };
        writer.request_update(index > 0, W, H).await.unwrap();
        let PooledEvent::Frame(frame) = reader.read_pooled_event().await.unwrap() else {
            panic!("expected RFB frame")
        };
        assert_eq!((frame.width, frame.height), (W, H));
        apply_reference(&mut oracle, rects, index);
        verify_pixels(&frame.pixels, &oracle);
        let mut spans = Vec::new();
        frame
            .damage()
            .for_each_span(|x, y, w, h| spans.push([x as u16, y as u16, w as u16, h as u16]));
        assert_eq!(
            tiles(&spans),
            tiles(rects),
            "damage coverage for {scene} sample {index}"
        );
    }
    let hash_expected = hash(&oracle);
    let frame_count = cycles * JOBS;
    let start = thread_cpu();
    let mut last = None;
    for n in 1..=frame_count {
        writer.request_update(true, W, H).await.unwrap();
        let PooledEvent::Frame(frame) = reader.read_pooled_event().await.unwrap() else {
            panic!("expected RFB frame")
        };
        if n == frame_count {
            last = Some(frame);
        }
    }
    let used = thread_cpu() - start;
    if let Some(frame) = last {
        verify_pixels(&frame.pixels, &oracle);
    }
    peer.join().unwrap().unwrap();
    let rect_count: usize = jobs.iter().map(Vec::len).sum();
    println!(
        "{scene} samples={JOBS} rects_per_cycle={rect_count} timed_frames={frame_count} reader_cpu_ms={:.3} final_rgba_fnv1a={hash_expected:016x}",
        used.as_secs_f64() * 1000.0
    );
    (used, frame_count)
}

fn main() {
    let arg = env::args().nth(1);
    let cycles = match arg.as_deref() {
        Some("--check-only") => 0,
        None => 32,
        Some(n) => n.parse::<usize>().unwrap(),
    };
    assert!(cycles <= 5000);
    pin_if_set("RFB_REPLAY_CPU");
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    let mut total = Duration::ZERO;
    let mut frame_count = 0;
    for (scene, jobs) in SCENES.into_iter().zip(geometry()) {
        let (used, n) = runtime.block_on(replay(scene, jobs, cycles));
        total += used;
        frame_count += n;
    }
    if frame_count > 0 {
        println!(
            "METRIC rfb_reader_us_per_update={:.5}",
            total.as_secs_f64() * 1e6 / frame_count as f64
        );
    }
}
