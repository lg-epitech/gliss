"""Plot the two stage replays and the full Distribox relay comparison."""
import argparse
import datetime
import html
import json
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from statistics import median

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.ticker import MaxNLocator

NAMES = {
    "typing": "Typing", "burst": "Typing bursts", "scroll": "Terminal scroll",
    "drag": "Window drag", "video": "Video region", "pages": "Page turns", "full": "Full frame",
}
STAGES = {"rfb": "RFB reader", "prepare": "RGBA → I420"}
BEFORE, AFTER = "beta.3", "PR"
INK, MUTED, LINE = "#182c35", "#506771", "#d6dfe1"
LOWER, HIGHER = "#087866", "#9b532e"


def value(v):
    if not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0:
        raise ValueError(f"invalid CPU sample {v!r}")
    return v


@dataclass
class Row:
    name: str
    before: float
    after: float
    unit: str

    @property
    def delta(self):
        return 100 * (self.after/self.before - 1)


def pair_row(name, b, a, unit):
    return Row(name, median(map(value, b)), median(map(value, a)), unit)


def delta_text(v):
    if abs(v) < .05:
        return "0.0%"
    return ("−" if v < 0 else "+") + f"{abs(v):.1f}%"


def amount(v, unit):
    return f"{v:,.2f}" if unit == "ms" or v < 10 else f"{v:,.1f}"


def read_stage(path, stage, target_pairs):
    data = json.loads(path.read_text())
    samples = data["pairs"]
    if data["stage"] != stage or len(samples) < 2 or (target_pairs and target_pairs != len(samples)):
        raise ValueError(f"{path}: unexpected stage or number of complete pairs ({len(samples)})")
    scenes = ["overall"] + (["scroll","drag","pages"] if stage == "rfb" else
                            ["typing","scroll","drag","video","pages","full"])
    rows = []
    for scene in scenes:
        b = [pair["before"]["usPerUpdate"][scene] for pair in samples]
        a = [pair["after"]["usPerUpdate"][scene] for pair in samples]
        rows.append(pair_row(STAGES[stage] if scene == "overall" else NAMES[scene], b, a, "µs"))
    return rows, len(samples)


def checked_runs(data, labels, allow_drag_misses):
    if len(labels) != 2 or len(set(labels)) != 2:
        raise ValueError(f"expected two distinct relay binary labels, got {labels}")
    runs = {label: [] for label in labels}
    accepted_failures = []
    for run in data["runs"]:
        label = run["label"]
        if run["pageErrors"]:
            raise ValueError(f"browser errors in round {run['round']+1} of {label}: {run['pageErrors']}")
        if set(run["scenarios"]) != set(data["scenarios"]):
            raise ValueError("run is missing one or more declared relay scenarios")
        for scene, entry in run["scenarios"].items():
            metrics = entry["metrics"]
            for problem in entry["problems"]:
                failure = f"round {run['round']+1} {label} {scene}: {problem}"
                miss = re.fullmatch(r"([1-9]\d*) of ([1-9]\d*) pointer positions missed", problem)
                if (not allow_drag_misses or scene != "drag" or not miss or
                    int(miss[1]) != metrics.get("pointerMissed") or int(miss[2]) != metrics.get("pointerSent")):
                    raise ValueError(f"unexpected relay failure: {failure}")
                accepted_failures.append(failure)
            if metrics.get("clientErrors", 0):
                raise ValueError(f"client decode/paint errors in {scene}")
            if scene == "drag":
                if metrics["pointerSent"] != metrics["pointerObserved"] + metrics["pointerMissed"]:
                    raise ValueError("inconsistent drag pointer counts")
                if metrics["pointerMissed"] and (not allow_drag_misses or not entry["problems"]):
                    raise ValueError("unresolved or unreported drag pointer loss")
        runs[label].append(run)
    if Counter(data["failures"]) != Counter(accepted_failures):
        raise ValueError(f"unexpected top-level relay failures: {data['failures']}")
    for rs in runs.values():
        rs.sort(key=lambda r:r["round"])
        if [r["round"] for r in rs] != list(range(data["rounds"])):
            raise ValueError("missing or repeated rounds in relay comparison")
    return runs


def drag_options(command):
    # All other settings applied by the driver appear explicitly in the report.
    # Typing cadence has no effect on a drag-only run.
    options = {}
    tokens = iter(command[1:])
    for token in tokens:
        k, eq, v = token.partition("=")
        if not k.startswith("--"):
            raise ValueError(f"unrecognized argument in relay command: {token}")
        if not eq:
            v = True if k == "--trace-refresh" else next(tokens)
        if k not in ("--scenarios", "--output", "--typing-keys"):
            options.setdefault(k, []).append(v)
    return options


def read_relay(path, before_label, after_label):
    data = json.loads(path.read_text())
    drag_path = path.with_name("drag8.json")
    corrected = json.loads(drag_path.read_text()) if drag_path.is_file() else None
    labels = [v["label"] for v in data["binaries"]]
    runs = checked_runs(data, labels, corrected is not None)
    before_label, after_label = before_label or labels[0], after_label or labels[1]
    if {before_label, after_label} != set(labels):
        raise ValueError(f"unknown relay labels {before_label}, {after_label}")
    drag_runs = None
    if corrected is not None:
        if "drag" not in data["scenarios"] or corrected["scenarios"] != ["drag","idle"]:
            raise ValueError("corrected report must contain only drag and the standard idle window")
        if corrected["rounds"] != 4:
            raise ValueError("the corrected drag comparison requires four paired rounds")
        for field in ("binaries","rounds","size","server","link","relay"):
            if data[field] != corrected[field]:
                raise ValueError(f"corrected drag does not match primary relay {field}")
        if any(not re.fullmatch(r"[0-9a-f]{64}", b["sha256"]) for b in data["binaries"]):
            raise ValueError("missing binary SHA-256 in relay comparison")
        for field in ("qemu","kernel","cpus"):
            if data["host"][field] != corrected["host"][field]:
                raise ValueError(f"corrected drag does not match primary host {field}")
        if drag_options(data["command"]) != drag_options(corrected["command"]):
            raise ValueError("effective drag benchmark command options do not match")
        drag_runs = checked_runs(corrected, labels, False)
        for run in corrected["runs"]:
            sends = run["scenarios"]["drag"]["sends"]
            if any(s.get("tag") == "release" for s in sends):
                raise ValueError("corrected drag released the pointer inside its marker observation window")
    ordered = [scene for scene in data["scenarios"] if scene != "idle"]
    rows = []
    for scene in ordered:
        def observations(label, field):
            selected = drag_runs if scene == "drag" and drag_runs is not None else runs
            return [r["scenarios"][scene]["metrics"][field] for r in selected[label]]
        rows.append(pair_row(NAMES.get(scene, scene.capitalize()), observations(before_label, "serverCpuMsPerFrame"),
                             observations(after_label, "serverCpuMsPerFrame"), "ms"))
    idle = None
    if "idle" in data["scenarios"]:
        idle = [median([r["scenarios"]["idle"]["metrics"]["serverCpuMs"] for r in runs[label]])
                for label in [before_label, after_label]]
    return rows, {
        "rounds": data["rounds"], "size": data["size"].replace("x","×"),
        "bitrate": float(data["server"][data["server"].index("--h264-bitrate") + 1])/1e6,
        "fps": int(data["server"][data["server"].index("--fps") + 1]),
        "hops": data["relay"]["relayHops"], "date": str(datetime.date.fromisoformat(data["startedAt"][:10])),
        "idle": idle, "separate_drag": drag_runs is not None,
    }


def domain(rows):
    values = [r.delta for r in rows] + [0]
    lo, hi = min(values), max(values)
    span = max(hi - lo, 6)
    loc = MaxNLocator(nbins=4, steps=[1, 2, 2.5, 5, 10])
    ticks = list(loc.tick_values(lo-span*.12, hi+span*.12))
    return ticks


def add_figure_row(fig, row, y, lower_bound, upper_bound, layout):
    fig.text(layout["name"], y, row.name, fontsize=12, color=INK, va="center")
    fig.text(layout["before"], y, amount(row.before, row.unit), ha="right", va="center", fontsize=11.8, color=MUTED)
    fig.text(layout["after"], y, amount(row.after, row.unit), ha="right", va="center", fontsize=11.8, color=INK,
             fontweight="bold")
    color = LOWER if row.delta < -.05 else HIGHER if row.delta >= .05 else MUTED
    fig.text(layout["delta"], y, delta_text(row.delta), ha="right", va="center", fontsize=11.8, color=color,
             fontweight="bold")
    ax = fig.add_axes((layout["plot"],y-.0115,layout["plotw"],.023))
    ax.set_xlim(lower_bound, upper_bound)
    ax.set_ylim(0,1)
    ax.axhline(.5,color=LINE,lw=.9,zorder=0)
    ax.axvline(0,color=MUTED,lw=.85,zorder=1)
    ax.plot([0,row.delta],[.5,.5],lw=4.2, solid_capstyle="butt", color=color, zorder=2)
    ax.scatter([row.delta],[.5],s=32,color=color,linewidths=0,zorder=3)
    ax.axis("off")


def fig_png(path, all_rows, counts, meta):
    stage_rows = [all_rows["rfb"][0], all_rows["prepare"][0]]
    end_rows = all_rows["relay"]
    layout = dict(name=.055, before=.395, after=.51, plot=.565, plotw=.275, delta=.944)
    plt.rcParams.update({"font.family":"DejaVu Sans","figure.facecolor":"white","axes.facecolor":"none",
                         "savefig.facecolor":"white","text.color":INK})
    # Allocate row space in physical inches, keeping the type size constant for all scenario counts.
    n = len(end_rows)
    height = 4.34 + .405*(2+n) + (.23 if meta["separate_drag"] else 0)
    fig = plt.figure(figsize=(9.1,height))
    y_inches = height-.39
    def text_at(x,y,text,**style):
        return fig.text(x, y/height, text, **style)
    text_at(.055,y_inches,"Gliss CPU on the Distribox desktop path",fontsize=21,fontweight="bold",va="center")
    y_inches -= .39
    text_at(.055,y_inches,f"{meta['size']}  ·  H.264 at {meta['bitrate']:g} Mbit/s  ·  {meta['fps']} fps cap  ·  "
            f"{meta['hops']} Distribox WebSocket relays",fontsize=10.9,color=MUTED)
    y_inches -= .54
    ticks = domain(stage_rows + end_rows)
    lo, hi = ticks[0], ticks[-1]
    def section(title, note, rows, y, category):
        text_at(.055,y,title,fontsize=14.4,fontweight="bold",va="center")
        y -= .245
        text_at(.055,y,note,fontsize=9.7,color=MUTED,va="center")
        y -= .34
        for x,s,align in [(layout["name"],category,"left"),(layout["before"],BEFORE,"right"),
                          (layout["after"],AFTER,"right"),(layout["delta"],"Change","right")]:
            text_at(x,y,s,fontsize=9.6,color=MUTED,ha=align,va="center")
        for tick in ticks:
            x = layout["plot"] + layout["plotw"]*(tick-lo)/(hi-lo)
            text_at(x,y,f"{tick:g}%".replace("-","−"),ha="center",va="center",fontsize=8.4,color=MUTED)
        fig.add_artist(plt.Line2D([.055,.944],[(y-.165)/height]*2,transform=fig.transFigure,color=LINE,lw=.8))
        for row in rows:
            y -= .405
            add_figure_row(fig,row,y/height,lo,hi,layout)
        return y
    y_inches = section("Isolated processing stages",
        "Thread CPU in µs per update. Medians across paired replays.", stage_rows,y_inches,"Stage")
    y_inches -= .67
    y_inches = section("Gliss through both relays",
        f"Gliss process CPU in ms per painted frame. Medians across {meta['rounds']} alternating-order rounds.",
        end_rows,y_inches,"Activity")
    y_inches -= .44
    fig.add_artist(plt.Line2D([.055,.944],[y_inches/height]*2,transform=fig.transFigure,color=LINE,lw=.8))
    y_inches -= .25
    detail = f"Paired samples per stage · RFB {counts['rfb']} and RGBA → I420 {counts['prepare']}."
    if meta["idle"] is not None:
        a,b = meta["idle"]
        detail += f"  Idle Gliss CPU over 5 s was {a:g} → {b:g} ms."
    text_at(.055, y_inches,detail,fontsize=9.2,color=MUTED)
    if meta["separate_drag"]:
        text_at(.055, y_inches-.23, "Window drag uses four separate paired rounds with the button held through marker observation.", fontsize=9.2, color=MUTED)
        y_inches -= .23
    text_at(.055, y_inches-.24, "QEMU/KVM guest and software-decoded Chromium on one host  ·  "
            + meta['date'],fontsize=9.2,color=MUTED)
    fig.savefig(path,dpi=190,metadata={"Title":"Gliss CPU on the Distribox desktop path"})
    plt.close(fig)


STYLE = """
:root{color-scheme:light dark;--ink:var(--foreground,CanvasText);--sub:var(--muted-foreground,GrayText);--line:var(--border,color-mix(in srgb,CanvasText 18%,transparent));--less:var(--success,#17846e);--more:var(--warning,#aa6532);font-family:var(--font-sans,system-ui,sans-serif);color:var(--ink)}
*{box-sizing:border-box}html,body{margin:0}main{max-width:980px;margin:0 auto;line-height:1.35;font-size:14px}
p,h2,h3{margin:0}h2{font-size:17px;letter-spacing:-.015em}p,.micro,figcaption{font-size:12px;color:var(--sub)}
.facts{display:grid;grid-template-columns:1fr 1fr;gap:20px;padding:3px 0 14px;border-bottom:1px solid var(--line)}
.fact:first-child{border-right:1px solid var(--line);padding-right:12px}
.fact h3{font-size:14px;font-weight:600}.fact strong{font-variant-numeric:tabular-nums;font-size:25px;letter-spacing:-.03em;margin-right:8px}
.fact p{margin-top:2px}.less{color:var(--less)}.more{color:var(--more)}.flat{color:var(--sub)}
nav{display:flex;flex-wrap:wrap;gap:5px;margin:14px 0 15px}
button{font:inherit;font-size:12px;font-weight:550;cursor:pointer;color:var(--sub);background:transparent;border:1px solid var(--line);border-radius:var(--radius,7px);padding:5px 9px}
button[aria-pressed=true]{color:var(--ink);border-color:var(--ring,currentColor);background:var(--secondary,transparent)}
button:focus-visible{outline:2px solid var(--ring,Highlight);outline-offset:2px}
.panel[hidden]{display:none} .panel>p{margin-top:3px}figure{margin:10px 0 0}.rows,.axis{display:grid;align-items:center;column-gap:12px;grid-template-columns:minmax(95px,1.15fr) 58px 58px minmax(86px,1.8fr) 58px}
.rows{min-height:37px;border-bottom:1px solid var(--line);font-variant-numeric:tabular-nums}.rows>span:first-child{font-weight:550}
.axis{min-height:27px;font-size:11px;color:var(--sub);border-bottom:1px solid var(--line)}
.num,.chg{text-align:right;white-space:nowrap}.chg{font-weight:650}.prior{color:var(--sub)}
.track,.ticks{position:relative}.track{height:17px}.track:before{content:"";position:absolute;left:0;right:0;top:8px;border-top:1px solid var(--line)}.track:after{content:"";position:absolute;top:2px;height:12px;left:var(--origin);width:1px;background:var(--sub)}
.stroke{position:absolute;height:4px;top:6.5px;left:var(--left);width:var(--width);background:currentColor;z-index:1}.dot{position:absolute;left:var(--point);top:8.5px;border-radius:50%;height:7px;width:7px;background:currentColor;transform:translate(-50%,-50%);z-index:2}
.ticks{height:15px}.tick{position:absolute;top:0;transform:translateX(-50%);font-size:10px;white-space:nowrap}
.tick:first-child{transform:translateX(0)}.tick:last-child{transform:translateX(-100%)}
figcaption{margin-top:9px;line-height:1.45}.context{margin-top:13px;font-size:11px;color:var(--sub)}
@media(max-width:540px){main{font-size:13px}.facts{gap:12px}.fact strong{font-size:22px}.rows,.axis{column-gap:7px;grid-template-columns:minmax(72px,1.2fr) 44px 44px minmax(45px,.9fr) 47px}.rows{min-height:42px}.ticks span:not(.zero){visibility:hidden}.num,.chg{font-size:12px}.axis{font-size:10px}.fact p{font-size:11px}nav{gap:4px}button{padding:5px 7px}}
@media(max-width:360px){.rows,.axis{column-gap:4px;grid-template-columns:minmax(65px,1.1fr) 40px 40px minmax(30px,.65fr) 44px}.num,.chg{font-size:11px}}
"""


def h(text): return html.escape(str(text))


def tone(delta):
    return "less" if delta < -.05 else "more" if delta >= .05 else "flat"


def panel(key,title,subtitle,details,rows):
    ticks = domain(rows)
    lo,hi = ticks[0],ticks[-1]
    pos = lambda val: (val-lo)/(hi-lo)*100
    fmt = lambda v: f"{v:.5f}%"
    parts = [f'<section class="panel" id="{key}"'+(' hidden' if key != "relay" else '')+'>',
             f'<h2>{h(title)}</h2><p>{h(subtitle)}</p><figure aria-label="{h(title)}">',
             '<div class="axis"><span>Workload</span><span class="num">'+BEFORE+'</span><span class="num">'+AFTER+
             '</span><div class="ticks" aria-hidden="true">']
    for tick in ticks:
        parts.append(f'<span class="tick {"zero" if tick==0 else ""}" style="left:{fmt(pos(tick))}">{h(f"{tick:g}%".replace("-","−"))}</span>')
    parts.append('</div><span class="num">Change</span></div>')
    for r in rows:
        origin,p = pos(0),pos(r.delta)
        styles = f'--origin:{fmt(origin)};--point:{fmt(p)};--left:{fmt(min(origin,p))};--width:{fmt(abs(p-origin))}'
        parts.extend([f'<div class="rows"><span>{h(r.name)}</span><span class="num prior">{amount(r.before,r.unit)}</span>',
            f'<span class="num">{amount(r.after,r.unit)}</span><div aria-hidden="true" class="track {tone(r.delta)}" style="{styles}">',
            f'<i class="stroke"></i><i class="dot"></i></div><span class="chg {tone(r.delta)}">{delta_text(r.delta)}</span></div>'])
    parts.append(f'<figcaption>{h(details)}</figcaption></figure></section>')
    return "".join(parts)


def write_html(path, rows, counts, meta):
    facts = []
    for key in ["rfb","prepare"]:
        r = rows[key][0]
        facts.append(f'<section class="fact"><h3>{h(r.name)}</h3><strong class="{tone(r.delta)}">{delta_text(r.delta)}</strong>'
                     f'<p>{amount(r.before,r.unit)} → {amount(r.after,r.unit)} µs of CPU per update</p></section>')
    filters = "".join(f'<button type="button" data-panel="{key}" aria-controls="{key}" aria-pressed="{str(key=="relay").lower()}">{label}</button>'
                      for key,label in [("relay","Through both relays"),("rfb",STAGES["rfb"]),("prepare",STAGES["prepare"])])
    idle = "" if meta["idle"] is None else f" Five seconds idle used {meta['idle'][0]:g} → {meta['idle'][1]:g} ms of Gliss CPU."
    drag_note = " Window drag uses four separate paired rounds with the button held through marker observation." if meta["separate_drag"] else ""
    end = panel("relay","Gliss CPU per painted frame","Milliseconds on the server. Negative changes use less CPU.",
                f"Medians of {meta['rounds']} alternating-order rounds through both Distribox WebSocket relays."
                +drag_note+idle,rows["relay"])
    rfb = panel("rfb","RFB reader CPU per framebuffer update","Microseconds on the reader thread.",
                f"Medians of {counts['rfb']} paired replays. The reader consumed four captured QEMU rectangle layouts per activity.",
                rows["rfb"][1:])
    prepare = panel("prepare","RGBA → I420 CPU per update","Microseconds to prepare the encoder’s pixel planes.",
                f"Medians of {counts['prepare']} paired replays. The stage summary uses the geometric mean of the five desktop activities. Full-frame conversion is shown separately.",
                rows["prepare"][1:])
    context = f"{meta['size']} · H.264 at {meta['bitrate']:g} Mbit/s · {meta['fps']} fps cap · QEMU/KVM and software-decoded Chromium · {meta['date']}"
    script = """document.querySelector('nav').addEventListener('click',event=>{
const active=event.target.closest('button');if(!active)return;
document.querySelectorAll('button[data-panel]').forEach(button=>button.setAttribute('aria-pressed',String(button===active)));
document.querySelectorAll('.panel').forEach(panel=>panel.hidden=panel.id!==active.dataset.panel);
});"""
    page = (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>Gliss CPU on the Distribox desktop path</title><style>{STYLE}</style></head><body>'
            f'<main><div class="facts">{"".join(facts)}</div><nav aria-label="Select a benchmark">{filters}</nav>'
            f'{end}{rfb}{prepare}<p class="context">{h(context)}</p></main><script>{script}</script></body></html>')
    path.write_text(page)


def main():
    root = Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data-dir",type=Path,default=root)
    p.add_argument("--out-dir",type=Path,default=root)
    p.add_argument("--prefix",default="distribox-performance")
    p.add_argument("--expected-pairs",type=int,default=6)
    p.add_argument("--before-label")
    p.add_argument("--after-label")
    a=p.parse_args()
    rows, counts = {}, {}
    for stage in STAGES:
        rows[stage], counts[stage] = read_stage(a.data_dir/f"{stage}-paired.json",stage,a.expected_pairs)
    rows["relay"],meta=read_relay(a.data_dir/"relays8.json",a.before_label,a.after_label)
    a.out_dir.mkdir(parents=True,exist_ok=True)
    png, page = (a.out_dir/f"{a.prefix}.{ext}" for ext in ["png","html"])
    fig_png(png, rows, counts, meta)
    write_html(page, rows, counts, meta)
    print(png)
    print(page)

if __name__ == "__main__":
    main()
